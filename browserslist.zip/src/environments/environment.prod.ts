export const environment = {
  production: true,
  baseMwUrl:'http://localhost:9999'
};
