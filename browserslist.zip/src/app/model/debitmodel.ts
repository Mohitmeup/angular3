export class Debitmodel {
public cardNumber:number;
public Status:String;
public nameOnCard:String;
public cvvNum:String;
public currentPin:String;
public cardType:String;
public dateOfExpiry:Date;
}
