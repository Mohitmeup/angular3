import { Debitmodel } from './debitmodel';

describe('Debitmodel', () => {
  it('should create an instance', () => {
    expect(new Debitmodel()).toBeTruthy();
  });
});
