import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockdebitComponent } from './blockdebit.component';

describe('BlockdebitComponent', () => {
  let component: BlockdebitComponent;
  let fixture: ComponentFixture<BlockdebitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockdebitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockdebitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
